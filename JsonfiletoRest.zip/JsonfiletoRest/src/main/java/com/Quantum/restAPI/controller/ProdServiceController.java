package com.Quantum.restAPI.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Quantum.resAPI.model.Product;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.core.subst.Parser;

@SuppressWarnings("unchecked")
@RestController
@EnableAutoConfiguration
public class ProdServiceController {

	@Autowired
	private ResourceLoader resourceLoader;
	static Map<String, Product> prodRepo = new HashMap<String, Product>();
	
	// Parsing JSON file
	public void parseJson(String Content) {

		JSONParser jsonParser = new JSONParser();
		// JSONObject jobj = new JSONObject();
		JSONArray productList = null;
		try {
			productList = (JSONArray) jsonParser.parse(Content);
			// prodRepo.put(Id, productList);
			productList.forEach(prod -> parseProdObject((JSONObject) prod));

		} catch (ParseException e) {
			e.printStackTrace();
		}
		// return prodRepo;
	}

	private static void parseProdObject(JSONObject product) {
		Product pro = new Product();
		// JSONObject prodObject = (JSONObject)product.get("");
		pro.setId((String) product.get("id"));
		pro.setName((String) product.get("name"));
		pro.setDescription((String) product.get("description"));
		pro.setPrice((String) product.get("price"));
		prodRepo.put(pro.getId(), new Product(pro.getId(), pro.getName(), pro.getDescription(), pro.getPrice()));
	}
	
	// Fetching Product details
	public JSONObject getProdDetails(String Id) {

		boolean flag = false;
		JSONObject jsonObj = new JSONObject();
		if (prodRepo.containsKey(Id) == true) {
			jsonObj.put("id", prodRepo.get(Id).getId());
			jsonObj.put("name", prodRepo.get(Id).getName());
			jsonObj.put("description", prodRepo.get(Id).getDescription());
			flag = true;
		} else {
			flag = false;
		}
		if (flag == false) {
			jsonObj.put("ErrorMsg", "Invalid Id");
		}
		return jsonObj;
	}
	
	// Fetching price of a product
	public JSONObject getProdPrice(String Id) {

		boolean flag = false;
		JSONObject jsonObj = new JSONObject();
		if (prodRepo.containsKey(Id) == true) {
			jsonObj.put("id", prodRepo.get(Id).getId());
			jsonObj.put("price", prodRepo.get(Id).getPrice());
			flag = true;
		} else {
			flag = false;
		}
		if (flag == false) {
			jsonObj.put("ErrorMsg", "Invalid Id");
		}
		return jsonObj;
	}

	// All product details
	@GetMapping(value = "/products")
	public ResponseEntity<Object> getResources() throws IOException {
		ProdServiceController controlObj = new ProdServiceController();
		String content = IOUtils.toString(resourceLoader.getResource("classpath:product.json").getInputStream());
		// String Id = body.get("id");
		controlObj.parseJson(content);
		return new ResponseEntity<>(prodRepo.values(), HttpStatus.OK);
	}

	// Details of Product without price
	@GetMapping(value = "/details")
	public JSONObject getDetails(@RequestBody Map<String, String> body) throws IOException {
		ProdServiceController controlObj = new ProdServiceController();
		String content = IOUtils.toString(resourceLoader.getResource("classpath:product.json").getInputStream());
		String Id = body.get("id");
		controlObj.parseJson(content);
		JSONObject jsonObj = controlObj.getProdDetails(Id);
		return jsonObj;
	}
	
	// Price of Product
	@GetMapping(value = "/price")
	public JSONObject getPriceDetails(@RequestBody Map<String, String> body) throws IOException {
		ProdServiceController controlObj = new ProdServiceController();
		String content = IOUtils.toString(resourceLoader.getResource("classpath:product.json").getInputStream());
		String Id = body.get("id");
		controlObj.parseJson(content);
		JSONObject jsonObj = controlObj.getProdPrice(Id);
		return jsonObj;
	}

}
